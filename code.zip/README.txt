The including files are representative of the project and cannot be run standalone and apart from Unity Engine. 

However, these 4 files are the most important files for the navigation:

FlowFieldAgent.cs is the imported script to the wheelchair.

FlowField.cs and GridController.cs are implementing all the flow field logic and are both imported into a game object named Grid in unity. The logic also supports the grid visualization shown in project's images.

HospitalSimulator.cs is the script that implements the looping weighted simulation when the respective button is pressed.